create definer = root@localhost view employees_salary as
select `employees`.`employees`.`emp_no`     AS `emp_no`,
       `employees`.`employees`.`first_name` AS `first_name`,
       `employees`.`employees`.`last_name`  AS `last_name`,
       sum(`employees`.`salaries`.`salary`) AS `salary`
from (`employees`.`employees`
         left join `employees`.`salaries` on ((`employees`.`employees`.`emp_no` = `employees`.`salaries`.`emp_no`)))
group by `employees`.`employees`.`emp_no`, `employees`.`employees`.`first_name`, `employees`.`employees`.`last_name`;

